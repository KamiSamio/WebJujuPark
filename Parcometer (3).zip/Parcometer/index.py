# Copyright 2024 <Samuel Masse, MASS83060001>

from flask import Flask
from flask import render_template
from flask import g
from .database import Database

app = Flask(__name__, static_url_path="", static_folder="static")


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        g._database = Database()
    return g._database


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.disconnect()


@app.route('/')
def form():
    # À remplacer par le contenu de votre choix.
    return render_template('form.html')
